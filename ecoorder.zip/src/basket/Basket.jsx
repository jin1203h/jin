function Basket() {
  return <ul>
    <div>
      <button>basket</button> <button>order</button>
    </div>
  </ul>
}

export default Basket
